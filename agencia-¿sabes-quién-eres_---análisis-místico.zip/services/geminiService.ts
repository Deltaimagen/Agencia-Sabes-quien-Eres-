
import { GoogleGenAI, Type } from "@google/genai";
import type { NumerologyNumbers } from '../types';

const apiKey = process.env.API_KEY;
if (!apiKey) {
    // In a real app, you might show a graceful error to the user.
    // For this example, we'll throw an error to make it clear during development.
    throw new Error("API_KEY environment variable not set. Please configure it to use the AI features.");
}

const ai = new GoogleGenAI({ apiKey });
const model = "gemini-2.5-flash";

const numerologyReportSchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING, description: "Un título místico y atractivo para el informe de numerología." },
        description: { type: Type.STRING, description: "Una breve introducción inspiradora (2-3 frases) sobre el significado general de la numerología para la persona, enfocada en el autodescubrimiento." },
        lifePath: {
            type: Type.OBJECT,
            properties: {
                name: { type: Type.STRING, description: "El nombre del número del Camino de Vida (ej. 'El Líder', 'El Cooperador')." },
                description: { type: Type.STRING, description: "Una descripción detallada, motivadora y profunda (un párrafo de 5-7 frases) del significado del número del Camino de Vida, explicando sus dones, desafíos y misión de vida." },
            },
            required: ["name", "description"]
        },
        expression: {
            type: Type.OBJECT,
            properties: {
                name: { type: Type.STRING, description: "El nombre del número de Expresión." },
                description: { type: Type.STRING, description: "Una descripción detallada, motivadora y profunda (un párrafo de 5-7 frases) del significado del número de Expresión, detallando talentos naturales y el potencial a desarrollar." },
            },
            required: ["name", "description"]
        },
        soulUrge: {
            type: Type.OBJECT,
            properties: {
                name: { type: Type.STRING, description: "El nombre del número del Impulso del Alma." },
                description: { type: Type.STRING, description: "Una descripción detallada, motivadora y profunda (un párrafo de 5-7 frases) del significado del número del Impulso del Alma, revelando las motivaciones internas y los deseos del corazón." },
            },
            required: ["name", "description"]
        },
        personality: {
            type: Type.OBJECT,
            properties: {
                name: { type: Type.STRING, description: "El nombre del número de Personalidad." },
                description: { type: Type.STRING, description: "Una descripción detallada, motivadora y profunda (un párrafo de 5-7 frases) del significado del número de Personalidad, describiendo cómo la persona es percibida por los demás y su máscara social." },
            },
            required: ["name", "description"]
        }
    },
    required: ["title", "description", "lifePath", "expression", "soulUrge", "personality"]
};


export const generateNumerologyReport = async (name: string, birthDate: string, numbers: NumerologyNumbers) => {
    const prompt = `
        Analiza el siguiente perfil numerológico basado en la numerología Pitagórica para una persona llamada ${name} nacida el ${birthDate}.
        Los números calculados son:
        - Camino de Vida: ${numbers.lifePath}
        - Expresión: ${numbers.expression}
        - Impulso del Alma: ${numbers.soulUrge}
        - Personalidad: ${numbers.personality}

        Proporciona una interpretación inspiradora, profunda y muy motivadora para cada número. Elabora sobre cómo estos dones y lecciones pueden ser utilizados para el crecimiento personal y la realización. El tono debe ser místico, positivo y empoderador.
        Genera una respuesta en formato JSON que se adhiera al esquema proporcionado. No incluyas markdown.
    `;
    
    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: numerologyReportSchema,
                temperature: 0.8,
            },
        });
        
        const jsonText = response.text.trim();
        return JSON.parse(jsonText);

    } catch (error) {
        console.error("Error generating numerology report:", error);
        throw new Error("No se pudo generar el informe numerológico. La IA podría estar ocupada. Por favor, inténtalo de nuevo.");
    }
};

export const generateGematriaInterpretation = async (word: string, value: number): Promise<string> => {
    const prompt = `
        Analiza la palabra "${word}" que tiene un valor de Gematria (aproximación Hebrea) de ${value}.
        Proporciona una interpretación mística, espiritual y motivadora en un párrafo corto pero profundo (alrededor de 3-4 frases). Explora el significado oculto de esta palabra y su valor numérico, y cómo su energía puede inspirar a la persona.
        El tono debe ser enigmático y revelador. Responde en texto plano, sin formato adicional.
    `;

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                temperature: 0.7,
            }
        });
        return response.text;
    } catch (error) {
        console.error("Error generating Gematria interpretation:", error);
        throw new Error("No se pudo generar la interpretación de Gematria.");
    }
};

export const generateDailyHoroscope = async (zodiacSign: string): Promise<string> => {
    const prompt = `
        Escribe un horóscopo diario único, inspirador, motivador y más extenso para el signo zodiacal ${zodiacSign}.
        El horóscopo debe tener dos párrafos (aproximadamente 6-8 frases en total). El primer párrafo debe enfocarse en la energía cósmica general del día y una reflexión para el alma. El segundo párrafo debe ofrecer consejos prácticos y poéticos para el amor, la carrera y el bienestar personal, empoderando al lector a aprovechar el día.
        El tono debe ser positivo, alentador y mágico. Responde en texto plano, sin formato adicional.
    `;

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                temperature: 0.9,
            }
        });
        return response.text;
    } catch (error) {
        console.error("Error generating horoscope:", error);
        throw new Error("No se pudo generar el horóscopo.");
    }
};
